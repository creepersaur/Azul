-------------------------------------

--  CreeperClI
--  This is a test script
--  feel free to delete this from the game and the directory

-------------------------------------

print('HELLO FROM AZUL')